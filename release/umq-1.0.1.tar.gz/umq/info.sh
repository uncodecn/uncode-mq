#!/bin/sh
java -jar lib/uncode-mq-1.0.0.jar -cfg conf/config.properties -info all
